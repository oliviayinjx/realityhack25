//@input SceneObject[] objects // 数组，存放 3D 对象
//@input float delay = 1.0 // 每个对象显示的延迟时间（秒）

var index = 0;

// 初始化函数，显示第一个对象
function initialize() {
    if (script.objects.length > 0) {
        // 显示第一个对象
        script.objects[0].enabled = true;

        // 为第一个对象添加碰撞监听
        setupCollisionListener(script.objects[0]);
    }
}

// 设置碰撞监听函数
function setupCollisionListener(object) {
    var collider = object.getComponent("Physics.ColliderComponent");

    if (collider) {
        // 监听对象的物理碰撞事件
        collider.addOnTriggerEnter(function(other) {
            // 当发生碰撞时，隐藏当前对象
            object.enabled = false;

            // 显示下一个对象
            index++;
            if (index < script.objects.length) {
                script.objects[index].enabled = true;

                // 为下一个对象设置碰撞监听
                setupCollisionListener(script.objects[index]);
            }
        });
    } else {
        print("对象没有 ColliderComponent: " + object.name);
    }
}

// 初始化脚本
initialize();
