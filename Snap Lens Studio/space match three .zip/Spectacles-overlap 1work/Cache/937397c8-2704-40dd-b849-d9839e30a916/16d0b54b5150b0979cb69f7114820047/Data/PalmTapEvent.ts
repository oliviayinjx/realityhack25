/**
 * Describes the Palm Tap event types
 */
export enum PalmTapEventType {
  Down = "Down",
  Up = "Up",
}
