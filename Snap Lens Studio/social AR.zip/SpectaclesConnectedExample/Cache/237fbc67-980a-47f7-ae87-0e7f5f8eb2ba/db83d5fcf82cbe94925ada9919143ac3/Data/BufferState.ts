import StateMachine from "../../../../SpectaclesInteractionKit/Utils/StateMachine"

export class BufferState {
  constructor(input: ScriptComponent, stateMachine: StateMachine) {}

  enter() {}

  exit() {}
}
