throw new Error('Cannot find compiled Script Module for the current file');
