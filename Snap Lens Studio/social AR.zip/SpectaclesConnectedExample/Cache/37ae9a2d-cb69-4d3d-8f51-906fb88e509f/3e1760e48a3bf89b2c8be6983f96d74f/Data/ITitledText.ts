export interface ITitledText {
  title: string
  text: string
}
