"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AllHandTypes = void 0;
/**
 * Describes a hand type, can be left or right
 */
exports.AllHandTypes = ["left", "right"];
//# sourceMappingURL=HandType.js.map
