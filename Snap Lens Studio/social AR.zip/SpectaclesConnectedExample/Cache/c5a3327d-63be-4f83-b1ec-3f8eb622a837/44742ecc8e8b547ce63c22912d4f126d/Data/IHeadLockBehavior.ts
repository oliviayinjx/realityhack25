export interface IHeadLockBehavior {
  distance: number
  bufferRotationDegrees: number
  bufferTranslationCentimeters: number
}
