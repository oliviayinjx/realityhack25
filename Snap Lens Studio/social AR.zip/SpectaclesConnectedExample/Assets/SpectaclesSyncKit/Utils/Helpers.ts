export function isNullOrUndefined(value: any): boolean {
  return value === null || value === undefined
}