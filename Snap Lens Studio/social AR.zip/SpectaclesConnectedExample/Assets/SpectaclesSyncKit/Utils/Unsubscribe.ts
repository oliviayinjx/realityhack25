/**
 * Type for a typical unsubscribe method call
 */
export type Unsubscribe = () => void
