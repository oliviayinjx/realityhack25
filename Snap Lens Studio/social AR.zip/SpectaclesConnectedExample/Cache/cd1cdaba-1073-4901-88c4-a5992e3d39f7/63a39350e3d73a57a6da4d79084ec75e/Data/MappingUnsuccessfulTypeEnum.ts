export enum MappingUnsuccessfulTypeEnum {
  Scan,
  Align,
}
