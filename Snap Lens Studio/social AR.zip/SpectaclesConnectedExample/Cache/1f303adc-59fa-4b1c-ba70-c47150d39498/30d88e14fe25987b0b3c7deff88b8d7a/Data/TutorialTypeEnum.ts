export enum TutorialTypeEnum {
  TutorialP1,
  TutorialP1TeachP2,
  TutorialP2
}
