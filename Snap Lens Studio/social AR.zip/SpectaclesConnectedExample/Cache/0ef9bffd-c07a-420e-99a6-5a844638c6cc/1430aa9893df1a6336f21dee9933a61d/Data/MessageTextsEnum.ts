export enum MessageTextsEnum {

  USER_ALIGNED = "USER_ALIGNED"

}
